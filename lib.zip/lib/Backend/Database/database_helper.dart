import 'package:chem_earth_app/utils/import_export.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();

  factory DatabaseHelper() => _instance;

  static Database? _database;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'chem_earth.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {

    // Formula Table
    await db.execute('''
  CREATE TABLE MST_Formula (
    FormulaID INTEGER PRIMARY KEY AUTOINCREMENT,
    SubTopicID INTEGER,
    Symbol TEXT,
    Name TEXT,
    MolWeight TEXT,
    Description TEXT,
    Uses TEXT,
    Bond TEXT
  )
''');

    // Mole Table
    await db.execute('''
      CREATE TABLE MST_Mole (
        MolecularID INTEGER PRIMARY KEY AUTOINCREMENT,
        SubTopicID INTEGER,
        SubTopicName TEXT,
        Remarks TEXT,
        IsFavourite INTEGER DEFAULT 0,
        SubTopicDisplayName TEXT,
        IsMolecularFavourite INTEGER DEFAULT 0
      )
    ''');

    // Molecular Table
    await db.execute('''
      CREATE TABLE MST_Molecular (
        MolecularID INTEGER PRIMARY KEY AUTOINCREMENT,
        MolecularName TEXT,
        MolecularFormula TEXT,
        Description TEXT,
        Remarks TEXT
      )
    ''');

    // Topics Table(Formulas Description)
    await db.execute('''
      CREATE TABLE MST_SubTopic (
        SubTopicID INTEGER PRIMARY KEY AUTOINCREMENT,
        TopicID INTEGER,
        SubTopicName TEXT,
        Remarks TEXT
      )
    ''');

    // Topic Table
    await db.execute('''
      CREATE TABLE MST_Topic (
        TopicID INTEGER PRIMARY KEY AUTOINCREMENT,
        TopicName TEXT,
        Remarks TEXT
      )
    ''');
  }

  // Get Method of Formulas
  Future<List<FormulaModel>> getAllFormulas() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('MST_Formula');

    return maps.map((map) => FormulaModel.fromMap(map)).toList();
  }

  // Post Method of Formulas
  Future<void> insertSampleFormulas() async {
    final db = await database;

    for (final formula in formulaList) {
      await db.insert(
        'MST_Formula',
        formula.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
  }


}