// region Dashboard
const String APPBAR_NAME = 'Chemistry!!';
const String NO_DATA_FOUND = 'No Data Found!!';
// region end

// region Home
const String HOME_SCREEN_APPBAR = 'Home Page';
// region end

// region Periodic Table
const String PERIODIC_TABLE_APPBAR = 'Periodic Table';
// region end

// region Profile
const String PROFILE_SCREEN_APPBAR = 'Profile';
// region end

// region Quiz
const String QUIZ_SCREEN_APPBAR = 'Quiz';
// region end