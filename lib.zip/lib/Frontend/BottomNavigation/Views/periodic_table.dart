import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PeriodicTable extends StatelessWidget {
  const PeriodicTable({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Get.isDarkMode;
    final backgroundColor = isDark ? Colors.black : Colors.white;
    final textColor = isDark ? Colors.white : Colors.black;

    // Updated category color map
    final Map<String, Color> categoryColors = {
      'Alkali Metal': const Color(0xFF81241E),
      'Alkaline Earth Metal': const Color(0xFF577821),
      'Transition Metal': const Color(0xFF066569),
      'Post-Transition Metal': const Color(0xFF0A4D4F),
      'Metalloid': const Color(0xFF9A7A00),
      'Nonmetal': const Color(0xFF015165),
      'Halogen': const Color(0xFF004D40),
      'Noble Gas': const Color(0xFF71216C),
      'Lanthanide': const Color(0xFF77165B),
      'Actinide': const Color(0xFF5A004C),
      'Other': Colors.grey,
    };

    // Sample element data
    final List<Map<String, dynamic>> elements = [
      {'symbol': 'H', 'name': 'Hydrogen', 'number': 1, 'category': 'Nonmetal'},
      {'symbol': 'He', 'name': 'Helium', 'number': 2, 'category': 'Noble Gas'},
      {'symbol': 'Li', 'name': 'Lithium', 'number': 3, 'category': 'Alkali Metal'},
      {'symbol': 'Be', 'name': 'Beryllium', 'number': 4, 'category': 'Alkaline Earth Metal'},
      {'symbol': 'B', 'name': 'Boron', 'number': 5, 'category': 'Metalloid'},
      {'symbol': 'C', 'name': 'Carbon', 'number': 6, 'category': 'Nonmetal'},
      {'symbol': 'N', 'name': 'Nitrogen', 'number': 7, 'category': 'Nonmetal'},
      {'symbol': 'O', 'name': 'Oxygen', 'number': 8, 'category': 'Nonmetal'},
      {'symbol': 'F', 'name': 'Fluorine', 'number': 9, 'category': 'Halogen'},
      {'symbol': 'Ne', 'name': 'Neon', 'number': 10, 'category': 'Noble Gas'},
      {'symbol': 'Na', 'name': 'Sodium', 'number': 11, 'category': 'Alkali Metal'},
      {'symbol': 'Mg', 'name': 'Magnesium', 'number': 12, 'category': 'Alkaline Earth Metal'},
      {'symbol': 'Al', 'name': 'Aluminium', 'number': 13, 'category': 'Post-Transition Metal'},
      {'symbol': 'Si', 'name': 'Silicon', 'number': 14, 'category': 'Metalloid'},
      {'symbol': 'P', 'name': 'Phosphorus', 'number': 15, 'category': 'Nonmetal'},
      {'symbol': 'S', 'name': 'Sulfur', 'number': 16, 'category': 'Nonmetal'},
      {'symbol': 'Cl', 'name': 'Chlorine', 'number': 17, 'category': 'Halogen'},
      {'symbol': 'Ar', 'name': 'Argon', 'number': 18, 'category': 'Noble Gas'},
      {'symbol': 'K', 'name': 'Potassium', 'number': 19, 'category': 'Alkali Metal'},
      {'symbol': 'Ca', 'name': 'Calcium', 'number': 20, 'category': 'Alkaline Earth Metal'},
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Periodic Table'),
        centerTitle: true,
        backgroundColor: isDark ? Colors.blueGrey[900] : Colors.blueGrey,
        foregroundColor: Colors.white,
      ),
      backgroundColor: backgroundColor,
      body: Padding(
        padding: const EdgeInsets.all(8),
        child: LayoutBuilder(
          builder: (context, constraints) {
            // Dynamically set crossAxisCount based on screen width
            int crossAxisCount = (constraints.maxWidth / 100).floor();
            if (crossAxisCount < 2) crossAxisCount = 2;

            return GridView.builder(
              itemCount: elements.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: crossAxisCount,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
                childAspectRatio: 1.1,
              ),
              itemBuilder: (context, index) {
                final element = elements[index];
                final category = element['category'] as String;
                final cardColor =
                    categoryColors[category] ?? categoryColors['Other']!;

                return GestureDetector(
                  onTap: () {
                    Get.snackbar(
                      '${element['symbol']} - ${element['name']}',
                      'Type: $category\nAtomic No: ${element['number']}',
                      backgroundColor:
                      isDark ? Colors.grey[900] : Colors.white,
                      colorText: textColor,
                      snackPosition: SnackPosition.BOTTOM,
                    );
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: cardColor,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: isDark
                              ? Colors.black26
                              : Colors.grey.withOpacity(0.3),
                          blurRadius: 4,
                          offset: const Offset(2, 2),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.all(8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.topRight,
                          child: Text(
                            element['number'].toString(),
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: Colors.black87,
                            ),
                          ),
                        ),
                        const Spacer(),
                        Center(
                          child: Text(
                            element['symbol'],
                            style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                        Center(
                          child: Text(
                            element['name'],
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              color: Colors.black87,
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Center(
                          child: Text(
                            category,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 10,
                              fontStyle: FontStyle.italic,
                              color: Colors.black54,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
