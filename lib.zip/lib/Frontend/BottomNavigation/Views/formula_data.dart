import 'package:chem_earth_app/utils/import_export.dart';

final List<FormulaModel> formulaList = [
  FormulaModel(
    formula: 'H₂O',
    topicDescription: 'Water',
    remarks: 'Colorless, odorless, tasteless liquid.',
    descTable: 'Used in drinking, cleaning, and industrial processes.',
  ),
  FormulaModel(
    formula: 'NaCl',
    topicDescription: 'Sodium Chloride',
    remarks: 'Ionic compound of sodium and chloride.',
    descTable: 'Used as table salt and preservative.',
  ),
  FormulaModel(
    formula: 'CO₂',
    topicDescription: 'Carbon Dioxide',
    remarks: 'Gas exhaled during respiration.',
    descTable: 'Used in fire extinguishers and carbonated drinks.',
  ),
  FormulaModel(
    formula: 'CH₄',
    topicDescription: 'Methane',
    remarks: 'Simplest alkane and main component of natural gas.',
    descTable: 'Used as a fuel and in chemical synthesis.',
  ),
  FormulaModel(
    formula: 'C₆H₁₂O₆',
    topicDescription: 'Glucose',
    remarks: 'Simple sugar and energy source in cells.',
    descTable: 'Used in respiration and food industry.',
  ),
  FormulaModel(
    formula: 'O₂',
    topicDescription: 'Oxygen',
    remarks: 'Essential for aerobic respiration.',
    descTable: 'Used in hospitals, welding, and space life support.',
  ),
  FormulaModel(
    formula: 'NH₃',
    topicDescription: 'Ammonia',
    remarks: 'Pungent-smelling gas composed of nitrogen and hydrogen.',
    descTable: 'Used in fertilizers and cleaning agents.',
  ),
  FormulaModel(
    formula: 'HCl',
    topicDescription: 'Hydrochloric Acid',
    remarks: 'Strong acid found in stomach.',
    descTable: 'Used in cleaning and chemical industries.',
  ),
  FormulaModel(
    formula: 'C₂H₅OH',
    topicDescription: 'Ethanol',
    remarks: 'Alcohol used as solvent and fuel.',
    descTable: 'Used in sanitizers, fuel, and beverages.',
  ),
  FormulaModel(
    formula: 'CaCO₃',
    topicDescription: 'Calcium Carbonate',
    remarks: 'Common substance found in rocks.',
    descTable: 'Used in construction, antacids, and chalk.',
  ),
];