class FormulaModel {
  final int? formulaID;
  final int? subTopicID;
  final String formula;
  final String topicDescription;
  final String remarks;
  final String descTable;

  FormulaModel({
    this.formulaID,
    this.subTopicID,
    required this.formula,
    required this.topicDescription,
    required this.remarks,
    required this.descTable,
  });

  factory FormulaModel.fromMap(Map<String, dynamic> map) {
    return FormulaModel(
      formulaID: map['FormulaID'],
      subTopicID: map['SubTopicID'],
      formula: map['Formula'] ?? '',
      topicDescription: map['TopicDescription'] ?? '',
      remarks: map['Remarks'] ?? '',
      descTable: map['DescTable'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'FormulaID': formulaID,
      'SubTopicID': subTopicID,
      'Formula': formula,
      'TopicDescription': topicDescription,
      'Remarks': remarks,
      'DescTable': descTable,
    };
  }
}